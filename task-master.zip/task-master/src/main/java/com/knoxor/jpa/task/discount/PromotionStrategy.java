package com.knoxor.jpa.task.discount;

import static com.knoxor.jpa.task.dto.repository.ProductType.INSURANCE;
import static com.knoxor.jpa.task.dto.repository.ProductType.MYPHONE_7;
import static com.knoxor.jpa.task.dto.repository.ProductType.MYPHONE_X;
import static com.knoxor.jpa.task.dto.repository.ProductType.PHONE_CASE;
import static com.knoxor.jpa.task.dto.repository.ProductType.SIM_CARD;
import static java.lang.Math.toIntExact;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

import org.springframework.stereotype.Component;

import com.knoxor.jpa.task.dto.repository.Product;
import com.knoxor.jpa.task.dto.web.Cart;
import com.knoxor.jpa.task.factory.ProductFactory;

@Component
public class PromotionStrategy {

  ProductFactory productFactory = new ProductFactory();

  public Cart applyPromotion(Cart cart) {

    // for every phone, if insurance exists then discount it
    // for every phone, add free sim

    // for every myphone7 add free sim
    cart.getProducts().stream()
                      .filter(p -> MYPHONE_7.equals(p.getProductType()))
                      .forEach(phone -> cart.addPromotion(productFactory.createProduct(SIM_CARD).price(BigDecimal.ZERO)));

    cart.getProducts().stream()
                      .filter(p -> MYPHONE_X.equals(p.getProductType()))
                      .forEach(phone -> cart.addPromotion(productFactory.createProduct(SIM_CARD).price(BigDecimal.ZERO)));

    // for every phone, if cart contains full price insurance, reduce cost
    Long noOfPhones = cart.getProducts().stream()
                                        .filter(p -> (MYPHONE_7.equals(p.getProductType())
                                                     || MYPHONE_X.equals(p.getProductType())))
                                        .count();
    List<Product> insuranceProducts = cart.getProducts()
                                          .stream()
                                          .filter(p -> INSURANCE.equals(p.getProductType()))
                                          .collect(Collectors.toList());

    IntStream.of(1, noOfPhones.intValue()).forEach(index -> modifyPrice(insuranceProducts));

    // do sim card rule last to more than 10 are not purchased when
    validateSimCards(cart);

    // add free case per 3 in cart
    applyPhoneCasePromotion(cart);

    return cart;
  }

  private void modifyPrice(List<Product> insuranceProducts) {
    insuranceProducts.forEach(insurance -> insurance.setPrice(insurance.getPrice()
                                                                       .divide(new BigDecimal(4))
                                                                        .multiply(new BigDecimal(3))));
  }

  private void applyPhoneCasePromotion(Cart cart) {
    long cases = cart.getProducts().stream()
        .filter(product -> PHONE_CASE.equals(product.getProductType())).count();
    IntStream.of(0, toIntExact(cases / 3))
        .forEach(value -> cart.getProducts().add(productFactory.createProduct(PHONE_CASE)));
  }

  private void validateSimCards(Cart cart) {
    List<Product> simCards = cart.getProducts().stream()
        .filter(product -> SIM_CARD.equals(product.getProductType())).collect(Collectors.toList());
    if (simCards != null && simCards.size() > 10) {
      cart.getProducts().removeAll(simCards);
      List<Product> allowedSimCards = cart.getProducts().subList(0, 9);
      allowedSimCards.stream().forEach(product -> cart.getProducts().add(product));
    }
  }
}
