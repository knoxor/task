package com.knoxor.jpa.task.dto.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.knoxor.jpa.task.discount.PromotionStrategy;
import com.knoxor.jpa.task.dto.repository.Product;

@Component
public class Cart {

  List<Product> products = new ArrayList<>();

  List<Product> promotions = new ArrayList<>();

  Double totalAmount;

  Double totalWithVat;

  public List<Product> getProducts() {
    return products;
  }

  public void setProducts(List<Product> products) {
    this.products = products;
  }

  public Double getTotalAmount() {
    return totalAmount;
  }

  public Double getTotalWithVat() {
    return totalWithVat;
  }

  public List<Product> getPromotions() {
    return promotions;
  }

  public void addPromotion(Product product) {
    this.promotions.add(product);
  }

  public void calculateTotalWithVat() {
    this.totalWithVat = this.products.stream().mapToDouble(p -> p.getPrice().doubleValue() + (p.getPrice().doubleValue() / 100) * p.getVatRate()).sum();
    this.totalWithVat += this.promotions.stream().mapToDouble(p -> p.getPrice().doubleValue() + (p.getPrice().doubleValue() / 100) * p.getVatRate()).sum();
  }

  public void calculateTotal() {
    this.totalAmount = products.stream().mapToDouble(product -> product.getPrice().doubleValue()).sum();
    this.totalAmount += promotions.stream().mapToDouble(product -> product.getPrice().doubleValue()).sum();
  }
}
