/****************************************************************************************************
 * Copyright (c) AIB Bank plc IT Ireland, BankCentre, BallsBridge, Dublin 4 All rights reserved.
 *
 * This software is the confidential and proprietary information of AIB Bank ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with AIB.
 *****************************************************************************************************/
package com.knoxor.jpa.task.visitor;

public interface Item {
  Double cost(CartVisitor cartVisitor);
}
