package com.knoxor.jpa.task.dto.repository;

public enum ProductType {
    MYPHONE_X,MYPHONE_7,INSURANCE,PHONE_CASE,SIM_CARD
}
