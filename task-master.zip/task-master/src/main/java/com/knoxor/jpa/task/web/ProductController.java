package com.knoxor.jpa.task.web;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import com.knoxor.jpa.task.discount.PromotionStrategy;
import com.knoxor.jpa.task.dto.repository.Product;
import com.knoxor.jpa.task.dto.web.Cart;
import com.knoxor.jpa.task.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityLinks;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    PromotionStrategy promotionStrategy;

    @RequestMapping(value = "/products", method = GET)
    public ResponseEntity<Iterable<Product>> getProductList() {
        Iterable<Product> all = productService.findAll();
        return ResponseEntity.ok(all);
    }

    @RequestMapping(value = "/products/", method = POST)
    public ResponseEntity<Product> updateProduct(@RequestBody Product product) {
        productService.update(product);
        return ResponseEntity.ok(product);
    }

    @RequestMapping(value = "/products/checkout", method = POST)
    public ResponseEntity checkout(@RequestBody Cart cart) {
      cart = promotionStrategy.applyPromotion(cart);
      cart.calculateTotal();
      cart.calculateTotalWithVat();
      return ResponseEntity.ok(cart);
    }
}
